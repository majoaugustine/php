<?php
$server="localhost";;
$username="root";
$password="";
$database="loginsystem";
$connection=mysqli_connect($server,$username,$password,$database);
if(!$connection){
    die('connection to this database failed due to'.mysqli_connect_error());
}